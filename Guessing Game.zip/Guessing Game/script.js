let targetNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;

function makeGuess() {
    const guessInput = document.getElementById("guessInput");
    const feedback = document.getElementById("feedback");
    const attemptsDisplay = document.getElementById("attempts");
    let guess = parseInt(guessInput.value);

    attempts++;
    
    if (guess < targetNumber) {
        feedback.textContent = "Too low! Try again.";
    } else if (guess > targetNumber) {
        feedback.textContent = "Too high! Try again.";
    } else {
        feedback.textContent = "Congratulations! You've guessed the number.";
        attemptsDisplay.textContent = "It took you " + attempts + " attempts.";
        guessInput.disabled = true;
    }
    
    guessInput.value = "";
    guessInput.focus();
}
